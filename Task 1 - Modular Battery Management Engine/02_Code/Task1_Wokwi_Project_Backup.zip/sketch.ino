#include <Wire.h>
#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);

// ---------------- GPIO ----------------
const int NUM_CELLS = 3;

int cellPins[NUM_CELLS] = {34, 35, 32};

#define GREEN_LED 18
#define YELLOW_LED 19
#define RED_LED 23
#define BUZZER 5
#define RELAY 4

// ---------------- Variables ----------------

float cellVoltage[NUM_CELLS];

float previousImbalance = 0;

String trend;
String soc;
String batteryStatus;

float adaptiveThreshold;

// ---------------- Read Cell Voltages ----------------

void readCellVoltages()
{
  for (int i = 0; i < NUM_CELLS; i++)
  {
    int adc = analogRead(cellPins[i]);
    cellVoltage[i] = adc * (3.3 / 4095.0);
  }
}

// ---------------- Average Voltage ----------------

float calculateAverageVoltage()
{
  float sum = 0;

  for (int i = 0; i < NUM_CELLS; i++)
    sum += cellVoltage[i];

  return sum / NUM_CELLS;
}

// ---------------- Highest ----------------

float getHighestVoltage()
{
  float highest = cellVoltage[0];

  for (int i = 1; i < NUM_CELLS; i++)
  {
    if (cellVoltage[i] > highest)
      highest = cellVoltage[i];
  }

  return highest;
}

// ---------------- Lowest ----------------

float getLowestVoltage()
{
  float lowest = cellVoltage[0];

  for (int i = 1; i < NUM_CELLS; i++)
  {
    if (cellVoltage[i] < lowest)
      lowest = cellVoltage[i];
  }

  return lowest;
}

// ---------------- Imbalance ----------------

float getVoltageImbalance()
{
  return getHighestVoltage() - getLowestVoltage();
}
// ---------------- SETUP ----------------

void setup()
{
  Serial.begin(115200);

  lcd.init();
  lcd.backlight();

  pinMode(GREEN_LED, OUTPUT);
  pinMode(YELLOW_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  pinMode(RELAY, OUTPUT);

  // Initially OFF
  digitalWrite(GREEN_LED, LOW);
  digitalWrite(YELLOW_LED, LOW);
  digitalWrite(RED_LED, LOW);
  digitalWrite(BUZZER, LOW);
  digitalWrite(RELAY, LOW);

  lcd.setCursor(0,0);
  lcd.print("EV Battery BMS");

  delay(1500);

  lcd.clear();
}
// ---------------- LOOP ----------------

void loop()
{
  readCellVoltages();

  float averageVoltage = calculateAverageVoltage();
  float highestVoltage = getHighestVoltage();
  float lowestVoltage = getLowestVoltage();
  float imbalance = getVoltageImbalance();

  // -------- Trend --------
  if (imbalance > previousImbalance + 0.01)
    trend = "Increasing";
  else if (imbalance < previousImbalance - 0.01)
    trend = "Decreasing";
  else
    trend = "Stable";

  previousImbalance = imbalance;

  // -------- Adaptive Threshold --------
  if (averageVoltage >= 2.8)
  {
    soc = "High";
    adaptiveThreshold = 0.10;
  }
  else if (averageVoltage >= 1.8)
  {
    soc = "Medium";
    adaptiveThreshold = 0.20;
  }
  else
  {
    soc = "Low";
    adaptiveThreshold = 0.30;
  }

  // -------- Battery Status --------
  if (imbalance <= adaptiveThreshold)
  {
    batteryStatus = "Healthy";
  }
  else if (imbalance <= (adaptiveThreshold * 2))
  {
    batteryStatus = "Warning";
  }
  else
  {
    batteryStatus = "Critical";
  }

  // -------- Outputs --------

  if (batteryStatus == "Healthy")
  {
    digitalWrite(GREEN_LED, HIGH);
    digitalWrite(YELLOW_LED, LOW);
    digitalWrite(RED_LED, LOW);

    noTone(BUZZER);
    digitalWrite(RELAY, HIGH);
  }
  else if (batteryStatus == "Warning")
  {
    digitalWrite(GREEN_LED, LOW);
    digitalWrite(YELLOW_LED, HIGH);
    digitalWrite(RED_LED, LOW);

    noTone(BUZZER);
    digitalWrite(RELAY, HIGH);
  }
  else
  {
    digitalWrite(GREEN_LED, LOW);
    digitalWrite(YELLOW_LED, LOW);
    digitalWrite(RED_LED, HIGH);

    tone(BUZZER, 1000);
    digitalWrite(RELAY, LOW);
  }

  // -------- LCD --------

  lcd.clear();

  lcd.setCursor(0, 0);
  lcd.print("SOC:");
  lcd.print(soc);

  lcd.setCursor(0, 1);
  lcd.print(batteryStatus);

  // -------- Serial Monitor --------

  Serial.println("--------------------------------");

  for (int i = 0; i < NUM_CELLS; i++)
  {
    Serial.print("Cell ");
    Serial.print(i + 1);
    Serial.print(": ");
    Serial.print(cellVoltage[i], 2);
    Serial.println(" V");
  }

  Serial.print("Highest Voltage : ");
  Serial.println(highestVoltage, 2);

  Serial.print("Lowest Voltage  : ");
  Serial.println(lowestVoltage, 2);

  Serial.print("Average Voltage : ");
  Serial.println(averageVoltage, 2);

  Serial.print("Imbalance       : ");
  Serial.println(imbalance, 2);

  Serial.print("Trend           : ");
  Serial.println(trend);

  Serial.print("Estimated SoC   : ");
  Serial.println(soc);

  Serial.print("Threshold       : ");
  Serial.println(adaptiveThreshold, 2);

  Serial.print("Battery Status  : ");
  Serial.println(batteryStatus);

  delay(500);
}